package com.song.Dao;
import org.hibernate.Session;
import com.song.entity.Student;
import com.song.hibernate.HibernateSessionFactory;

public class StudentDeleteDao {
	public static void DeleteStudent(String sid)
	{
	//����*************************************************************
			Session session = HibernateSessionFactory.getSession();
			Student student = (Student)session.load(Student.class, sid);	//��ȡ����			
	//����*************************************************************
			//System.out.println(sid);
			student.setSId(sid);
			session.beginTransaction();
			session.delete(student);		
			session.getTransaction().commit();
			session.close();
	}
}
