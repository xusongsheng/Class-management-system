package com.song.Dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import com.song.entity.Course;
import com.song.entity.Grade;
import com.song.entity.GradeId;
import com.song.entity.Student;
import com.song.hibernate.HibernateSessionFactory;

public class GradeListDao {
	public static List<Grade> ListGrade(String csid,String sid,String info)
	{
	//����*************************************************************
		GradeId id = new GradeId(new Course(csid),new Student(sid));
		//String hql = "from Grade where id.course.csid ="+csid+"and id.student.sid like %"+info+"%";
		String hql = "from Grade grade where (grade.id.course.csName like '%"+info+"%' or grade.id.student.SName like '%"+info+"%'or grade.GGrade like '%"+info+"%') and (grade.id.course.csId like'%"+csid+"%'and grade.id.student.SId like'%"+sid+"%')";
		Session session = HibernateSessionFactory.getSession();
	//����*************************************************************
		session.beginTransaction();	
		Query query = session.createQuery(hql);
		List<Grade> grade = query.list();
		session.getTransaction().commit();
		//session.close();
		return grade;
	}
}
