package com.song.Dao;
import org.hibernate.Session;
import com.song.hibernate.HibernateSessionFactory;
import com.song.entity.Classes;
public class ClassDeleteDao {
		public static void DeleteClass(String cid)
		{
		//����*************************************************************
			Session session = HibernateSessionFactory.getSession();
			Classes classes = (Classes)session.load(Classes.class, cid);	//��ȡ����
			System.out.println(cid);
		//����*************************************************************
			classes.setCId(cid);
			session.beginTransaction();
			session.delete(classes);		
			session.getTransaction().commit();
			session.close();
		}
}
