package com.song.Dao;

import org.hibernate.Session;
import com.song.hibernate.HibernateSessionFactory;
import com.song.entity.Classes;
import com.song.entity.Student;
public class StudentAdd {
	/**
	 * @param args
	 */
	public static boolean addStudent(String sid,String spassword,String sname,
			String ssex,String sbirth,String sphone,String splace,String classes)
	{
		Student student = new Student();
		student.setSId(sid);
		student.setSPassword(spassword);
		student.setSName(sname);
		student.setSSex(ssex);
		student.setSBirth(sbirth);
		student.setSPhone(sphone);
		student.setSPlace(splace);
		student.setClasses(new Classes(classes));
		
		
		
		System.out.println(sid);
		System.out.println(spassword);
		System.out.println(sname);
		System.out.println(ssex);
		System.out.println(sbirth);
		System.out.println(sphone);
		System.out.println(splace);
		System.out.println(classes);
		//1.��ʼ������ȡ�����ļ�
		//Configuration config = new Configuration().configure();
		//2.��ȡ����sessionFactory
		//SessionFactory sessionFactory = config.buildSessionFactory();
		//3.��session
		Session session = HibernateSessionFactory.getSession();
		try
		{
			session.beginTransaction();
			session.save(student);		
			session.getTransaction().commit();
		}
		catch(Exception e)
		{
			if(session.beginTransaction()!=null)
				session.beginTransaction().rollback();//����ع�
			e.printStackTrace();
			return false;
		}
		finally
		{
			session.close();
		}
		return true;
	}
}
