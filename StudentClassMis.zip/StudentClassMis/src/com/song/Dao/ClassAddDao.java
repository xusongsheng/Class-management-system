package com.song.Dao;
import org.hibernate.Session;
import com.song.hibernate.HibernateSessionFactory;
import com.song.entity.Classes;
public class ClassAddDao {
	public static void AddClass(String cid,String cname)
	{
	//����*************************************************************
		Classes classes = new Classes();
		classes.setCId(cid);
		classes.setCName(cname);
	//����*************************************************************
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();
		session.save(classes);		
		session.getTransaction().commit();
		session.close();
	}
	
	
}
