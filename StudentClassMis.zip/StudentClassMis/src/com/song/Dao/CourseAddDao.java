package com.song.Dao;
import org.hibernate.Session;
import com.song.hibernate.HibernateSessionFactory;
import com.song.entity.Course;
public class CourseAddDao {
	public static void AddCourse(String csid,String csname,String cscharacter,double csgrade)
	{
	//����*************************************************************
		Course course = new Course();
		course.setCsId(csid);
		course.setCsName(csname);
		course.setCsCharacter(cscharacter);
		course.setCsGrade(csgrade);
	//����*************************************************************
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();
		session.save(course);		
		session.getTransaction().commit();
		session.close();
	}
}