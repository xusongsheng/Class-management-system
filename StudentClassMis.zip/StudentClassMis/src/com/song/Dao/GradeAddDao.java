package com.song.Dao;
import org.hibernate.Session;
import com.song.entity.Grade;
import com.song.entity.GradeId;
import com.song.entity.Course;
import com.song.entity.Student;
import com.song.hibernate.HibernateSessionFactory;

public class GradeAddDao {
	public static void AddGrade(String csid,String sid,double grade)
	{
	//����*************************************************************
		Grade grades = new Grade();
		grades.setId(new GradeId(new Course(csid),new Student(sid)));
		grades.setGGrade(grade);
	//����*************************************************************
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();
		session.save(grades);		
		session.getTransaction().commit();
		session.close();
	}
}
