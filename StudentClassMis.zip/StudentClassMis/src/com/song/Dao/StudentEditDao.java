package com.song.Dao;
import org.hibernate.Session;
import com.song.hibernate.HibernateSessionFactory;
import com.song.entity.Classes;
import com.song.entity.Student;
public class StudentEditDao {
	public static void EditStudent(String sid,String sname,String ssex,
			String sbirth,String sphone,String splace,String classes)
	{
	//����*************************************************************
		Session session = HibernateSessionFactory.getSession();
		Student student = (Student)session.load(Student.class, sid);	//��ȡ����		
	//����*************************************************************
		student.setSId(sid);
		student.setSName(sname);
		student.setSSex(ssex);
		student.setSBirth(sbirth);
		student.setSPhone(sphone);
		student.setSPlace(splace);
		student.setClasses(new Classes(classes));
		session.beginTransaction();
		session.update(student);		
		session.getTransaction().commit();
		session.close();
	}
}
