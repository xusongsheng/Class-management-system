package com.song.Dao;
import org.hibernate.Session;
import com.song.hibernate.HibernateSessionFactory;
import com.song.entity.Classes;
public class ClassEditDao {
	public static void EditClass(String cid,String cname)
	{
	//����*************************************************************
		Session session = HibernateSessionFactory.getSession();
		Classes classes = (Classes)session.load(Classes.class, cid);	//��ȡ����	
	//����*************************************************************
		classes.setCId(cid);
		classes.setCName(cname);
		session.beginTransaction();
		session.update(classes);		
		session.getTransaction().commit();
		session.close();
	}
}
