package com.song.Dao;
import org.hibernate.Session;
import com.song.hibernate.HibernateSessionFactory;
import com.song.entity.Course;
public class CourseDeleteDao {
	public static void DeleteCourse(String csid)
	{
	//����*************************************************************
			Session session = HibernateSessionFactory.getSession();
			Course course = (Course)session.load(Course.class, csid);	//��ȡ����		
	//����*************************************************************
			course.setCsId(csid);
			session.beginTransaction();
			session.delete(course);		
			session.getTransaction().commit();
			session.close();
	}
}
