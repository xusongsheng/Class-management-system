package com.song.Dao;
import java.util.*;
import org.hibernate.Session;
import com.song.hibernate.HibernateSessionFactory;
import com.song.entity.Student;
public class LoginDao {

	public static int JudgeLogin(String username,String password)
	{
		//����*************************************************************
			Session session = HibernateSessionFactory.getSession();
		//����*************************************************************
			String hql = "FROM Student WHERE SId ='"+ username+"' AND SPassword ='"+password+"'";
			try{
				@SuppressWarnings("unchecked")
				List<Student> list = session.createQuery(hql).list();
				if(!list.isEmpty())
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
			catch(Exception e)
			{
				System.out.println(e);
				return 0;
			}
	}
}
