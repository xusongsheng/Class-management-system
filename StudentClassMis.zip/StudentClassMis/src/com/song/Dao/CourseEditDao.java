package com.song.Dao;
import org.hibernate.Session;
import com.song.hibernate.HibernateSessionFactory;
import com.song.entity.Course;
public class CourseEditDao {
	public static void EditCourse(String csid,String csname,String cscharacter,double csgrade)
	{
	//����*************************************************************
		Session session = HibernateSessionFactory.getSession();
		Course course = (Course)session.load(Course.class, csid);	//��ȡ����		
	//����*************************************************************
		course.setCsId(csid);
		course.setCsName(csname);
		course.setCsCharacter(cscharacter);
		course.setCsGrade(csgrade);
		session.beginTransaction();
		session.update(course);		
		session.getTransaction().commit();
		session.close();
	}
}