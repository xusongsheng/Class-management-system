package com.song.action;

import java.util.List;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.song.Dao.GradeListDao;
import com.song.entity.Grade;

public class GradeList extends ActionSupport {
	//servletRequest.setCharacterEncoding('utf-8');
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//����*************************************************************
	private String csid;
	private String sid;
	private String info;
	//����*************************************************************
	public String getCsid() {
		return csid;
	}
	public void setCsid(String csid) {
		this.csid = csid;
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		try
		{
			//System.out.println(info);
			List<Grade> gradelist = GradeListDao.ListGrade(csid, sid, info);
			ActionContext context=ActionContext.getContext();
			context.put("gradelist",gradelist);
		}
		catch(Exception e)
		{
			System.out.println(e);//��ӡ������Ϣ
			return "Error";
		}
		return "Success";
		
	}
	
}
