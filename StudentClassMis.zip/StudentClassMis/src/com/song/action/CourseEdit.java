package com.song.action;
import com.song.Dao.*;
import com.opensymphony.xwork2.ActionSupport;

public class CourseEdit extends ActionSupport {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//����*************************************************************
	private String csid="";
	private String csname="";
	private String cscharacter="";
	private double csgrade=0;
	//����*************************************************************
	public String getCsid() {
		return csid;
	}
	public void setCsid(String csid) {
		this.csid = csid;
	}
	public String getCsname() {
		return csname;
	}
	public void setCsname(String csname) {
		this.csname = csname;
	}
	public String getCscharacter() {
		return cscharacter;
	}
	public void setCscharacter(String cscharacter) {
		this.cscharacter = cscharacter;
	}
	public double getCsgrade() {
		return csgrade;
	}
	public void setCsgrade(double csgrade) {
		this.csgrade = csgrade;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		try
		{
			CourseEditDao.EditCourse(csid, csname, cscharacter, csgrade);
		}
		catch(Exception e)
		{
			System.out.println(e);//��ӡ������Ϣ
			return "Error";
		}
		return "Success";

	}
	
}
