package com.song.action;
import com.opensymphony.xwork2.ActionSupport;
import com.song.Dao.LoginDao;

public class Login extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//����*************************************************************
		private String username="";
		private String password="";
	//����*************************************************************
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		@Override
		public String execute() throws Exception {
			// TODO Auto-generated method stub
			int i;
			//System.out.println("action:"+username);
			//System.out.println(password);
			try
			{
				i = LoginDao.JudgeLogin(username, password);
				if(i == 1)
				{
					return "Success";
				}
				else
				{
					return "Error";
				}
			}
			catch(Exception e)
			{
				System.out.println(e);
				return "Error";
			}
		}
		
}
