package com.song.action;

import com.opensymphony.xwork2.ActionSupport;
import com.song.Dao.GradeAddDao;

public class GradeAdd extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//����*************************************************************
		private String csid="";
		private String sid="";
		private double grade=0;
	//����*************************************************************
		public String getCsid() {
			return csid;
		}
		public void setCsid(String csid) {
			this.csid = csid;
		}
		public String getSid() {
			return sid;
		}
		public void setSid(String sid) {
			this.sid = sid;
		}
		public double getGrade() {
			return grade;
		}
		public void setGrade(double grade) {
			this.grade = grade;
		}
		@Override
		public String execute() throws Exception {
			// TODO Auto-generated method stub
			try
			{
				System.out.println(csid);
				System.out.println(sid);
				System.out.println(grade);
				GradeAddDao.AddGrade(csid, sid, grade);
			}
			catch(Exception e)
			{
				System.out.println(e);//��ӡ������Ϣ
				return "Error";
			}
			return "Success";
		}
		
}
