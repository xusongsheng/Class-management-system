package com.song.action;

import com.opensymphony.xwork2.ActionSupport;
import com.song.Dao.StudentEditDao;

public class StudentEdit extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//����*************************************************************
		private String sid = "";
		private String sname = "";
		private String ssex = "";
		private String sbirth = "";
		private String sphone = "";
		private String splace = "";
		private String classes = "";
		//����*************************************************************
		


		public String getSid() {
			return sid;
		}

		public void setSid(String sid) {
			this.sid = sid;
		}

		public String getSname() {
			return sname;
		}

		public void setSname(String sname) {
			this.sname = sname;
		}

		public String getSsex() {
			return ssex;
		}

		public void setSsex(String ssex) {
			this.ssex = ssex;
		}

		public String getSbirth() {
			return sbirth;
		}

		public void setSbirth(String sbirth) {
			this.sbirth = sbirth;
		}

		public String getSphone() {
			return sphone;
		}

		public void setSphone(String sphone) {
			this.sphone = sphone;
		}

		public String getSplace() {
			return splace;
		}

		public void setSplace(String splace) {
			this.splace = splace;
		}

		public String getClasses() {
			return classes;
		}

		public void setClasses(String classes) {
			this.classes = classes;
		}
		@Override
		public String execute() throws Exception {
			// TODO Auto-generated method stub
			try
			{
				StudentEditDao.EditStudent(sid, sname, ssex, sbirth, sphone, splace, classes);
			}
			catch(Exception e)
			{
				System.out.println(e);//��ӡ������Ϣ
				return "Error";
			}
			return "Success";
		}
		

}
