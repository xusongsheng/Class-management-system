package com.song.action;
import com.song.Dao.ClassEditDao;
import com.opensymphony.xwork2.ActionSupport;

public class ClassEdit extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//����*************************************************************
	private String cid="";
	private String cname="";
	//����*************************************************************
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		try
		{
			//��ȡ�ӽ������������Ϣ
			ClassEditDao.EditClass(cid, cname);
		}
		catch(Exception e)
		{
			System.out.println(e);//��ӡ������Ϣ
			return "Error";
		}
		return "Success";
	}
	
}
