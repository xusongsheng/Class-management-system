package com.song.action;
import com.song.Dao.ClassAddDao;
import com.opensymphony.xwork2.ActionSupport;

public class ClassAdd extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//����*************************************************************
	private String cid="";
	private String cname="";
	//����*************************************************************
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	@Override
	public String execute() throws Exception {
		try
		{
			//��ȡ�ӽ������������Ϣ
			ClassAddDao.AddClass(cid, cname);
		}
		catch(Exception e)
		{
			System.out.println(e);//��ӡ������Ϣ
			return "Error";
		}
		return "Success";
	}
	
}
