package com.song.action;

import com.opensymphony.xwork2.ActionSupport;
import com.song.Dao.StudentDeleteDao;

public class StudentDelete extends ActionSupport {

	/**
	 * 
	 */
		private static final long serialVersionUID = 1L;
	//����*************************************************************
		private String sid="";

	//����*************************************************************
		public String getSid() {
			return sid;
		}
	
		public void setSid(String sid) {
			this.sid = sid;
		}
	@Override
		public String execute() throws Exception {
		// TODO Auto-generated method stub
		try
		{
			StudentDeleteDao.DeleteStudent(sid);
		}
		catch(Exception e)
		{
			System.out.println(e);//��ӡ������Ϣ
			return "Error";
		}
		return "Success";

	}
}
