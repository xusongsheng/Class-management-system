package com.song.action;

import com.opensymphony.xwork2.ActionSupport;
import com.song.Dao.ClassDeleteDao;

public class ClassDelete extends ActionSupport {

	/**
	 * 
	 */
		private static final long serialVersionUID = 1L;
	//����*************************************************************
		private String cid="";
	//����*************************************************************
		public String getCid() {
			return cid;
		}
		public void setCid(String cid) {
			this.cid = cid;
		}
		@Override
		public String execute() throws Exception {
			// TODO Auto-generated method stub
			try
			{
				//System.out.println("action:"+cid);
				//��ȡ�ӽ������������Ϣ
				ClassDeleteDao.DeleteClass(cid);
			}
			catch(Exception e)
			{
				System.out.println(e);//��ӡ������Ϣ
				return "Error";
			}
			return "Success";
		}
}
