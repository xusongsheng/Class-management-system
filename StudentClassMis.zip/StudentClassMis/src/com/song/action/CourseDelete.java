package com.song.action;
import com.song.Dao.*;
import com.opensymphony.xwork2.ActionSupport;

public class CourseDelete extends ActionSupport {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//����*************************************************************
	private String csid="";

	//����*************************************************************
	public String getCsid() {
		return csid;
	}
	public void setCsid(String csid) {
		this.csid = csid;
	}
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		try
		{
			CourseDeleteDao.DeleteCourse(csid);
		}
		catch(Exception e)
		{
			System.out.println(e);//��ӡ������Ϣ
			return "Error";
		}
		return "Success";

	}
	
}
