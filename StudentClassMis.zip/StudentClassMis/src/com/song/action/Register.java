package com.song.action;
import com.song.Dao.*;
import com.opensymphony.xwork2.ActionSupport;

public class Register extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	//����*************************************************************
	private String sid = "";
	private String spassword = "";
	private String sname = "";
	private String ssex = "";
	private String sbirth = "";
	private String sphone = "";
	private String splace = "";
	private String classes = "";
	//����*************************************************************
	


	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getSpassword() {
		return spassword;
	}

	public void setSpassword(String spassword) {
		this.spassword = spassword;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSsex() {
		return ssex;
	}

	public void setSsex(String ssex) {
		this.ssex = ssex;
	}

	public String getSbirth() {
		return sbirth;
	}

	public void setSbirth(String sbirth) {
		this.sbirth = sbirth;
	}

	public String getSphone() {
		return sphone;
	}

	public void setSphone(String sphone) {
		this.sphone = sphone;
	}

	public String getSplace() {
		return splace;
	}

	public void setSplace(String splace) {
		this.splace = splace;
	}

	public String getClasses() {
		return classes;
	}

	public void setClasses(String classes) {
		this.classes = classes;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		boolean judge = false;
		System.out.println(sid);
		System.out.println(sname);
		System.out.println(spassword);
		try
		{
			//��ȡ�ӽ������������Ϣ
			judge = StudentAdd.addStudent(getSid(), getSpassword(), getSname(), getSsex(), getSbirth(), getSphone(), getSplace(), getClasses());
			if(judge == true)
				return "Success";
			else
				return "Error";
		}
		catch(Exception e)
		{
			System.out.println(e);//��ӡ������Ϣ
			return "Error";
		}
	}
	
}
