package com.song.entity;

import java.util.HashSet;
import java.util.Set;

/**
 * Student entity. @author MyEclipse Persistence Tools
 */

public class Student implements java.io.Serializable {

	// Fields

	private String SId;
	private Classes classes;
	private String SPassword;
	private String SName;
	private String SSex;
	private String SBirth;
	private String SPhone;
	private String SPlace;
	private Set grades = new HashSet(0);

	// Constructors

	/** default constructor */
	public Student() {
	}

	/** minimal constructor */
	public Student(String SId) {
		this.SId = SId;
	}

	/** full constructor */
	public Student(String SId, Classes classes, String SPassword, String SName,
			String SSex, String SBirth, String SPhone, String SPlace, Set grades) {
		this.SId = SId;
		this.classes = classes;
		this.SPassword = SPassword;
		this.SName = SName;
		this.SSex = SSex;
		this.SBirth = SBirth;
		this.SPhone = SPhone;
		this.SPlace = SPlace;
		this.grades = grades;
	}

	// Property accessors

	public String getSId() {
		return this.SId;
	}

	public void setSId(String SId) {
		this.SId = SId;
	}

	public Classes getClasses() {
		return this.classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	public String getSPassword() {
		return this.SPassword;
	}

	public void setSPassword(String SPassword) {
		this.SPassword = SPassword;
	}

	public String getSName() {
		return this.SName;
	}

	public void setSName(String SName) {
		this.SName = SName;
	}

	public String getSSex() {
		return this.SSex;
	}

	public void setSSex(String SSex) {
		this.SSex = SSex;
	}

	public String getSBirth() {
		return this.SBirth;
	}

	public void setSBirth(String SBirth) {
		this.SBirth = SBirth;
	}

	public String getSPhone() {
		return this.SPhone;
	}

	public void setSPhone(String SPhone) {
		this.SPhone = SPhone;
	}

	public String getSPlace() {
		return this.SPlace;
	}

	public void setSPlace(String SPlace) {
		this.SPlace = SPlace;
	}

	public Set getGrades() {
		return this.grades;
	}

	public void setGrades(Set grades) {
		this.grades = grades;
	}

}