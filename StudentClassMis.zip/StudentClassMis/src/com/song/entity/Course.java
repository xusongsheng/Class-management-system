package com.song.entity;

import java.util.HashSet;
import java.util.Set;

/**
 * Course entity. @author MyEclipse Persistence Tools
 */

public class Course implements java.io.Serializable {

	// Fields

	private String csId;
	private String csName;
	private String csCharacter;
	private Double csGrade;
	private Set grades = new HashSet(0);

	// Constructors

	/** default constructor */
	public Course() {
	}

	/** minimal constructor */
	public Course(String csId) {
		this.csId = csId;
	}

	/** full constructor */
	public Course(String csId, String csName, String csCharacter,
			Double csGrade, Set grades) {
		this.csId = csId;
		this.csName = csName;
		this.csCharacter = csCharacter;
		this.csGrade = csGrade;
		this.grades = grades;
	}

	// Property accessors

	public String getCsId() {
		return this.csId;
	}

	public void setCsId(String csId) {
		this.csId = csId;
	}

	public String getCsName() {
		return this.csName;
	}

	public void setCsName(String csName) {
		this.csName = csName;
	}

	public String getCsCharacter() {
		return this.csCharacter;
	}

	public void setCsCharacter(String csCharacter) {
		this.csCharacter = csCharacter;
	}

	public Double getCsGrade() {
		return this.csGrade;
	}

	public void setCsGrade(Double csGrade) {
		this.csGrade = csGrade;
	}

	public Set getGrades() {
		return this.grades;
	}

	public void setGrades(Set grades) {
		this.grades = grades;
	}

}